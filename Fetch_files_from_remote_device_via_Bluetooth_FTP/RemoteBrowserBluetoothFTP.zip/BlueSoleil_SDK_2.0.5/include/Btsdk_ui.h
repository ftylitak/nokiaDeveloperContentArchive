/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
*
* Copyright (c) 1999-2007 IVT Corporation
*
* All rights reserved.
* 
---------------------------------------------------------------------------*/
 
/////////////////////////////////////////////////////////////////////////////
// Module Name:
//     Btsdk_ui.h
// Abstract:
//     
// Usage:
//     #include "Btsdk_ui.h"
// 
// Author://     
//     
// Revision History:
//     2007-12-27		Created
// 
/////////////////////////////////////////////////////////////////////////////


#ifndef _BTSDK_UI_H
#define _BTSDK_UI_H

#include "Btsdk_Macro.h"
#include "Btsdk_Stru.h"
#include "Btsdk_API.h"

#endif