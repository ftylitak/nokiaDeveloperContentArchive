/********************************************************************************
** Form generated from reading UI file 'QuteMessenger.ui'
**
** Created: Wed 4. Jan 19:52:41 2012
**      by: Qt User Interface Compiler version 4.7.4
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_QUTEMESSENGER_H
#define UI_QUTEMESSENGER_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QListWidget>
#include <QtGui/QMainWindow>
#include <QtGui/QPushButton>
#include <QtGui/QTabWidget>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_QuteMessengerClass
{
public:
    QWidget *centralwidget;
    QHBoxLayout *horizontalLayout_2;
    QTabWidget *tabWidget;
    QWidget *deviceInRangeTab;
    QVBoxLayout *verticalLayout;
    QLabel *deviceLabel;
    QListWidget *deviceListWidget;
    QPushButton *devSearchButton;

    void setupUi(QMainWindow *QuteMessengerClass)
    {
        if (QuteMessengerClass->objectName().isEmpty())
            QuteMessengerClass->setObjectName(QString::fromUtf8("QuteMessengerClass"));
        QuteMessengerClass->setWindowModality(Qt::WindowModal);
        QuteMessengerClass->resize(343, 426);
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(QuteMessengerClass->sizePolicy().hasHeightForWidth());
        QuteMessengerClass->setSizePolicy(sizePolicy);
        QFont font;
        font.setFamily(QString::fromUtf8("Comic Sans MS"));
        font.setPointSize(8);
        font.setBold(false);
        font.setWeight(50);
        font.setStyleStrategy(QFont::PreferAntialias);
        QuteMessengerClass->setFont(font);
        QuteMessengerClass->setContextMenuPolicy(Qt::NoContextMenu);
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/programIcon/val1.png"), QSize(), QIcon::Normal, QIcon::Off);
        QuteMessengerClass->setWindowIcon(icon);
        QuteMessengerClass->setAutoFillBackground(true);
        QuteMessengerClass->setToolButtonStyle(Qt::ToolButtonIconOnly);
        QuteMessengerClass->setDocumentMode(false);
        QuteMessengerClass->setTabShape(QTabWidget::Rounded);
        QuteMessengerClass->setDockNestingEnabled(false);
        QuteMessengerClass->setDockOptions(QMainWindow::AllowTabbedDocks|QMainWindow::AnimatedDocks);
        QuteMessengerClass->setUnifiedTitleAndToolBarOnMac(false);
        centralwidget = new QWidget(QuteMessengerClass);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        QSizePolicy sizePolicy1(QSizePolicy::Maximum, QSizePolicy::Maximum);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(centralwidget->sizePolicy().hasHeightForWidth());
        centralwidget->setSizePolicy(sizePolicy1);
        centralwidget->setContextMenuPolicy(Qt::NoContextMenu);
        horizontalLayout_2 = new QHBoxLayout(centralwidget);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        tabWidget = new QTabWidget(centralwidget);
        tabWidget->setObjectName(QString::fromUtf8("tabWidget"));
        sizePolicy.setHeightForWidth(tabWidget->sizePolicy().hasHeightForWidth());
        tabWidget->setSizePolicy(sizePolicy);
        tabWidget->setContextMenuPolicy(Qt::NoContextMenu);
        tabWidget->setTabPosition(QTabWidget::North);
        tabWidget->setTabShape(QTabWidget::Triangular);
        tabWidget->setElideMode(Qt::ElideNone);
        tabWidget->setDocumentMode(false);
        tabWidget->setTabsClosable(true);
        tabWidget->setMovable(true);
        deviceInRangeTab = new QWidget();
        deviceInRangeTab->setObjectName(QString::fromUtf8("deviceInRangeTab"));
        sizePolicy.setHeightForWidth(deviceInRangeTab->sizePolicy().hasHeightForWidth());
        deviceInRangeTab->setSizePolicy(sizePolicy);
        deviceInRangeTab->setContextMenuPolicy(Qt::NoContextMenu);
        deviceInRangeTab->setAutoFillBackground(false);
        verticalLayout = new QVBoxLayout(deviceInRangeTab);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        deviceLabel = new QLabel(deviceInRangeTab);
        deviceLabel->setObjectName(QString::fromUtf8("deviceLabel"));
        deviceLabel->setContextMenuPolicy(Qt::NoContextMenu);

        verticalLayout->addWidget(deviceLabel);

        deviceListWidget = new QListWidget(deviceInRangeTab);
        deviceListWidget->setObjectName(QString::fromUtf8("deviceListWidget"));
        sizePolicy.setHeightForWidth(deviceListWidget->sizePolicy().hasHeightForWidth());
        deviceListWidget->setSizePolicy(sizePolicy);
        deviceListWidget->setContextMenuPolicy(Qt::NoContextMenu);
        deviceListWidget->setAutoFillBackground(true);
        deviceListWidget->setStyleSheet(QString::fromUtf8(""));
        deviceListWidget->setFrameShape(QFrame::Box);
        deviceListWidget->setFrameShadow(QFrame::Plain);
        deviceListWidget->setLineWidth(1);
        deviceListWidget->setMidLineWidth(1);
        deviceListWidget->setWordWrap(false);

        verticalLayout->addWidget(deviceListWidget);

        devSearchButton = new QPushButton(deviceInRangeTab);
        devSearchButton->setObjectName(QString::fromUtf8("devSearchButton"));
        sizePolicy.setHeightForWidth(devSearchButton->sizePolicy().hasHeightForWidth());
        devSearchButton->setSizePolicy(sizePolicy);
        devSearchButton->setContextMenuPolicy(Qt::NoContextMenu);

        verticalLayout->addWidget(devSearchButton);

        verticalLayout->setStretch(0, 1);
        verticalLayout->setStretch(1, 8);
        verticalLayout->setStretch(2, 2);
        tabWidget->addTab(deviceInRangeTab, QString());

        horizontalLayout_2->addWidget(tabWidget);

        QuteMessengerClass->setCentralWidget(centralwidget);

        retranslateUi(QuteMessengerClass);

        tabWidget->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(QuteMessengerClass);
    } // setupUi

    void retranslateUi(QMainWindow *QuteMessengerClass)
    {
        QuteMessengerClass->setWindowTitle(QApplication::translate("QuteMessengerClass", "QuteMessenger", 0, QApplication::UnicodeUTF8));
        deviceLabel->setText(QApplication::translate("QuteMessengerClass", "Devices in range:", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        deviceListWidget->setToolTip(QString());
#endif // QT_NO_TOOLTIP
        devSearchButton->setText(QApplication::translate("QuteMessengerClass", "Start Search", 0, QApplication::UnicodeUTF8));
        tabWidget->setTabText(tabWidget->indexOf(deviceInRangeTab), QApplication::translate("QuteMessengerClass", "Devices", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class QuteMessengerClass: public Ui_QuteMessengerClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_QUTEMESSENGER_H
