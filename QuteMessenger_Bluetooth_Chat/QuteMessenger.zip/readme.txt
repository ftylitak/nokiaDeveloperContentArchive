Complies with the QBluetoothZero API repository version 55.

See QBluetoothZero's project page: https://projects.forum.nokia.com/qbluetooth