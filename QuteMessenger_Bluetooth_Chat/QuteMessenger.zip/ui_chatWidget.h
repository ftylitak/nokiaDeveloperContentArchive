/********************************************************************************
** Form generated from reading UI file 'chatWidget.ui'
**
** Created: Wed 4. Jan 19:52:41 2012
**      by: Qt User Interface Compiler version 4.7.4
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CHATWIDGET_H
#define UI_CHATWIDGET_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QGroupBox>
#include <QtGui/QHeaderView>
#include <QtGui/QTextEdit>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>
#include "qinputbox.h"

QT_BEGIN_NAMESPACE

class Ui_chatWidget
{
public:
    QVBoxLayout *verticalLayout_3;
    QGroupBox *messageLogBox;
    QVBoxLayout *verticalLayout;
    QTextEdit *textEdit;
    QGroupBox *writeMessageBox;
    QVBoxLayout *verticalLayout_2;
    QInputBox *lineEdit;

    void setupUi(QWidget *chatWidget)
    {
        if (chatWidget->objectName().isEmpty())
            chatWidget->setObjectName(QString::fromUtf8("chatWidget"));
        chatWidget->resize(269, 387);
        QFont font;
        font.setFamily(QString::fromUtf8("Comic Sans MS"));
        font.setPointSize(7);
        chatWidget->setFont(font);
        verticalLayout_3 = new QVBoxLayout(chatWidget);
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        messageLogBox = new QGroupBox(chatWidget);
        messageLogBox->setObjectName(QString::fromUtf8("messageLogBox"));
        QFont font1;
        font1.setFamily(QString::fromUtf8("Times New Roman"));
        messageLogBox->setFont(font1);
        messageLogBox->setFlat(false);
        messageLogBox->setCheckable(false);
        verticalLayout = new QVBoxLayout(messageLogBox);
        verticalLayout->setSpacing(1);
        verticalLayout->setContentsMargins(1, 1, 1, 1);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        textEdit = new QTextEdit(messageLogBox);
        textEdit->setObjectName(QString::fromUtf8("textEdit"));
        QFont font2;
        font2.setFamily(QString::fromUtf8("Comic Sans MS"));
        textEdit->setFont(font2);
        textEdit->setFocusPolicy(Qt::NoFocus);
        textEdit->setFrameShape(QFrame::Panel);
        textEdit->setFrameShadow(QFrame::Sunken);
        textEdit->setLineWidth(2);
        textEdit->setMidLineWidth(0);
        textEdit->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        textEdit->setReadOnly(true);

        verticalLayout->addWidget(textEdit);


        verticalLayout_3->addWidget(messageLogBox);

        writeMessageBox = new QGroupBox(chatWidget);
        writeMessageBox->setObjectName(QString::fromUtf8("writeMessageBox"));
        verticalLayout_2 = new QVBoxLayout(writeMessageBox);
        verticalLayout_2->setSpacing(1);
        verticalLayout_2->setContentsMargins(1, 1, 1, 1);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        lineEdit = new QInputBox(writeMessageBox);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));
        lineEdit->setFrameShape(QFrame::Panel);
        lineEdit->setFrameShadow(QFrame::Sunken);
        lineEdit->setLineWidth(2);
        lineEdit->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);

        verticalLayout_2->addWidget(lineEdit);


        verticalLayout_3->addWidget(writeMessageBox);

        verticalLayout_3->setStretch(0, 10);
        verticalLayout_3->setStretch(1, 2);

        retranslateUi(chatWidget);

        QMetaObject::connectSlotsByName(chatWidget);
    } // setupUi

    void retranslateUi(QWidget *chatWidget)
    {
        chatWidget->setWindowTitle(QApplication::translate("chatWidget", "Form", 0, QApplication::UnicodeUTF8));
        messageLogBox->setTitle(QApplication::translate("chatWidget", "Device", 0, QApplication::UnicodeUTF8));
        writeMessageBox->setTitle(QString());
    } // retranslateUi

};

namespace Ui {
    class chatWidget: public Ui_chatWidget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CHATWIDGET_H
