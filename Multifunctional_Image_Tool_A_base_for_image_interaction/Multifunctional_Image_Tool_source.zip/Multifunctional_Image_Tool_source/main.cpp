#include <QtGui/QApplication>
#include "qmlapplicationviewer.h"
#include "imagehandler.h"
#include <QDeclarativeContext>
#include <QDeclarativeEngine>

//#include <QZXing.h>

Q_DECL_EXPORT int main(int argc, char *argv[])
{
    QScopedPointer<QApplication> app(createApplication(argc, argv));

  //  QZXing::registerQMLTypes();

    ImageHandler imageHandler("imageRepository");

    QmlApplicationViewer viewer;
    viewer.rootContext()->setContextProperty("imageHandler", &imageHandler);
    viewer.engine()->addImageProvider(imageHandler.providerName(), &imageHandler);
    viewer.setMainQmlFile(QLatin1String("qml/MultiFunctionImageTool/main.qml"));
    viewer.showExpanded();

    return app->exec();
}
